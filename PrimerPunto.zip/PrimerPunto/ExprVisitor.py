# Generated from Expr.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprParser import ExprParser
else:
    from ExprParser import ExprParser

# This class defines a complete generic visitor for a parse tree produced by ExprParser.

class ExprVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ExprParser#programa.
    def visitPrograma(self, ctx:ExprParser.ProgramaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#imprimirExpresion.
    def visitImprimirExpresion(self, ctx:ExprParser.ImprimirExpresionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#asignar.
    def visitAsignar(self, ctx:ExprParser.AsignarContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#lineaVacia.
    def visitLineaVacia(self, ctx:ExprParser.LineaVaciaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#parentesis.
    def visitParentesis(self, ctx:ExprParser.ParentesisContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#sumaResta.
    def visitSumaResta(self, ctx:ExprParser.SumaRestaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#multDiv.
    def visitMultDiv(self, ctx:ExprParser.MultDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#complejo.
    def visitComplejo(self, ctx:ExprParser.ComplejoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#variable.
    def visitVariable(self, ctx:ExprParser.VariableContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#entero.
    def visitEntero(self, ctx:ExprParser.EnteroContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#flotante.
    def visitFlotante(self, ctx:ExprParser.FlotanteContext):
        return self.visitChildren(ctx)



del ExprParser