# Generated from Expr.g4 by ANTLR 4.9.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\20")
        buf.write("/\4\2\t\2\4\3\t\3\4\4\t\4\3\2\6\2\n\n\2\r\2\16\2\13\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3\27\n\3\3\4\3\4")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4\"\n\4\3\4\3\4\3\4\3\4")
        buf.write("\3\4\3\4\7\4*\n\4\f\4\16\4-\13\4\3\4\2\3\6\5\2\4\6\2\4")
        buf.write("\3\2\6\7\3\2\b\t\2\64\2\t\3\2\2\2\4\26\3\2\2\2\6!\3\2")
        buf.write("\2\2\b\n\5\4\3\2\t\b\3\2\2\2\n\13\3\2\2\2\13\t\3\2\2\2")
        buf.write("\13\f\3\2\2\2\f\3\3\2\2\2\r\16\5\6\4\2\16\17\7\17\2\2")
        buf.write("\17\27\3\2\2\2\20\21\7\n\2\2\21\22\7\3\2\2\22\23\5\6\4")
        buf.write("\2\23\24\7\17\2\2\24\27\3\2\2\2\25\27\7\17\2\2\26\r\3")
        buf.write("\2\2\2\26\20\3\2\2\2\26\25\3\2\2\2\27\5\3\2\2\2\30\31")
        buf.write("\b\4\1\2\31\32\7\4\2\2\32\33\5\6\4\2\33\34\7\5\2\2\34")
        buf.write("\"\3\2\2\2\35\"\7\r\2\2\36\"\7\n\2\2\37\"\7\13\2\2 \"")
        buf.write("\7\f\2\2!\30\3\2\2\2!\35\3\2\2\2!\36\3\2\2\2!\37\3\2\2")
        buf.write("\2! \3\2\2\2\"+\3\2\2\2#$\f\t\2\2$%\t\2\2\2%*\5\6\4\n")
        buf.write("&\'\f\b\2\2\'(\t\3\2\2(*\5\6\4\t)#\3\2\2\2)&\3\2\2\2*")
        buf.write("-\3\2\2\2+)\3\2\2\2+,\3\2\2\2,\7\3\2\2\2-+\3\2\2\2\7\13")
        buf.write("\26!)+")
        return buf.getvalue()


class ExprParser ( Parser ):

    grammarFileName = "Expr.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'('", "')'", "'*'", "'/'", "'+'", 
                     "'-'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "MULT", "DIV", "SUMA", "RESTA", "VARIABLE", "NUMERO_INT", 
                      "NUMERO_FLOAT", "NUMERO_COMPLEJO", "SIGNO", "FIN_LINEA", 
                      "ESPACIO" ]

    RULE_programa = 0
    RULE_sentencia = 1
    RULE_expresion = 2

    ruleNames =  [ "programa", "sentencia", "expresion" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    MULT=4
    DIV=5
    SUMA=6
    RESTA=7
    VARIABLE=8
    NUMERO_INT=9
    NUMERO_FLOAT=10
    NUMERO_COMPLEJO=11
    SIGNO=12
    FIN_LINEA=13
    ESPACIO=14

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def sentencia(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ExprParser.SentenciaContext)
            else:
                return self.getTypedRuleContext(ExprParser.SentenciaContext,i)


        def getRuleIndex(self):
            return ExprParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)




    def programa(self):

        localctx = ExprParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 7 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 6
                self.sentencia()
                self.state = 9 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ExprParser.T__1) | (1 << ExprParser.VARIABLE) | (1 << ExprParser.NUMERO_INT) | (1 << ExprParser.NUMERO_FLOAT) | (1 << ExprParser.NUMERO_COMPLEJO) | (1 << ExprParser.FIN_LINEA))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SentenciaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ExprParser.RULE_sentencia

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LineaVaciaContext(SentenciaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.SentenciaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FIN_LINEA(self):
            return self.getToken(ExprParser.FIN_LINEA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLineaVacia" ):
                listener.enterLineaVacia(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLineaVacia" ):
                listener.exitLineaVacia(self)


    class ImprimirExpresionContext(SentenciaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.SentenciaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expresion(self):
            return self.getTypedRuleContext(ExprParser.ExpresionContext,0)

        def FIN_LINEA(self):
            return self.getToken(ExprParser.FIN_LINEA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImprimirExpresion" ):
                listener.enterImprimirExpresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImprimirExpresion" ):
                listener.exitImprimirExpresion(self)


    class AsignarContext(SentenciaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.SentenciaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VARIABLE(self):
            return self.getToken(ExprParser.VARIABLE, 0)
        def expresion(self):
            return self.getTypedRuleContext(ExprParser.ExpresionContext,0)

        def FIN_LINEA(self):
            return self.getToken(ExprParser.FIN_LINEA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignar" ):
                listener.enterAsignar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignar" ):
                listener.exitAsignar(self)



    def sentencia(self):

        localctx = ExprParser.SentenciaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_sentencia)
        try:
            self.state = 20
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = ExprParser.ImprimirExpresionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 11
                self.expresion(0)
                self.state = 12
                self.match(ExprParser.FIN_LINEA)
                pass

            elif la_ == 2:
                localctx = ExprParser.AsignarContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 14
                self.match(ExprParser.VARIABLE)
                self.state = 15
                self.match(ExprParser.T__0)
                self.state = 16
                self.expresion(0)
                self.state = 17
                self.match(ExprParser.FIN_LINEA)
                pass

            elif la_ == 3:
                localctx = ExprParser.LineaVaciaContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 19
                self.match(ExprParser.FIN_LINEA)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ExprParser.RULE_expresion

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ParentesisContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expresion(self):
            return self.getTypedRuleContext(ExprParser.ExpresionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParentesis" ):
                listener.enterParentesis(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParentesis" ):
                listener.exitParentesis(self)


    class SumaRestaContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ExprParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(ExprParser.ExpresionContext,i)

        def SUMA(self):
            return self.getToken(ExprParser.SUMA, 0)
        def RESTA(self):
            return self.getToken(ExprParser.RESTA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumaResta" ):
                listener.enterSumaResta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumaResta" ):
                listener.exitSumaResta(self)


    class MultDivContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ExprParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(ExprParser.ExpresionContext,i)

        def MULT(self):
            return self.getToken(ExprParser.MULT, 0)
        def DIV(self):
            return self.getToken(ExprParser.DIV, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultDiv" ):
                listener.enterMultDiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultDiv" ):
                listener.exitMultDiv(self)


    class ComplejoContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERO_COMPLEJO(self):
            return self.getToken(ExprParser.NUMERO_COMPLEJO, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplejo" ):
                listener.enterComplejo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplejo" ):
                listener.exitComplejo(self)


    class VariableContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VARIABLE(self):
            return self.getToken(ExprParser.VARIABLE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)


    class EnteroContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERO_INT(self):
            return self.getToken(ExprParser.NUMERO_INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEntero" ):
                listener.enterEntero(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEntero" ):
                listener.exitEntero(self)


    class FlotanteContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ExprParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERO_FLOAT(self):
            return self.getToken(ExprParser.NUMERO_FLOAT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFlotante" ):
                listener.enterFlotante(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFlotante" ):
                listener.exitFlotante(self)



    def expresion(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ExprParser.ExpresionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_expresion, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 31
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [ExprParser.T__1]:
                localctx = ExprParser.ParentesisContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 23
                self.match(ExprParser.T__1)
                self.state = 24
                self.expresion(0)
                self.state = 25
                self.match(ExprParser.T__2)
                pass
            elif token in [ExprParser.NUMERO_COMPLEJO]:
                localctx = ExprParser.ComplejoContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 27
                self.match(ExprParser.NUMERO_COMPLEJO)
                pass
            elif token in [ExprParser.VARIABLE]:
                localctx = ExprParser.VariableContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 28
                self.match(ExprParser.VARIABLE)
                pass
            elif token in [ExprParser.NUMERO_INT]:
                localctx = ExprParser.EnteroContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 29
                self.match(ExprParser.NUMERO_INT)
                pass
            elif token in [ExprParser.NUMERO_FLOAT]:
                localctx = ExprParser.FlotanteContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 30
                self.match(ExprParser.NUMERO_FLOAT)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 41
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 39
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                    if la_ == 1:
                        localctx = ExprParser.MultDivContext(self, ExprParser.ExpresionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expresion)
                        self.state = 33
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 34
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==ExprParser.MULT or _la==ExprParser.DIV):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 35
                        self.expresion(8)
                        pass

                    elif la_ == 2:
                        localctx = ExprParser.SumaRestaContext(self, ExprParser.ExpresionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expresion)
                        self.state = 36
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 37
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==ExprParser.SUMA or _la==ExprParser.RESTA):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 38
                        self.expresion(7)
                        pass

             
                self.state = 43
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.expresion_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expresion_sempred(self, localctx:ExpresionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         




