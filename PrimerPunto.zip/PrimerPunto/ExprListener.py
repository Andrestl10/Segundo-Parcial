# Generated from Expr.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .ExprParser import ExprParser
else:
    from ExprParser import ExprParser

# This class defines a complete listener for a parse tree produced by ExprParser.
class ExprListener(ParseTreeListener):

    # Enter a parse tree produced by ExprParser#programa.
    def enterPrograma(self, ctx:ExprParser.ProgramaContext):
        pass

    # Exit a parse tree produced by ExprParser#programa.
    def exitPrograma(self, ctx:ExprParser.ProgramaContext):
        pass


    # Enter a parse tree produced by ExprParser#imprimirExpresion.
    def enterImprimirExpresion(self, ctx:ExprParser.ImprimirExpresionContext):
        pass

    # Exit a parse tree produced by ExprParser#imprimirExpresion.
    def exitImprimirExpresion(self, ctx:ExprParser.ImprimirExpresionContext):
        pass


    # Enter a parse tree produced by ExprParser#asignar.
    def enterAsignar(self, ctx:ExprParser.AsignarContext):
        pass

    # Exit a parse tree produced by ExprParser#asignar.
    def exitAsignar(self, ctx:ExprParser.AsignarContext):
        pass


    # Enter a parse tree produced by ExprParser#lineaVacia.
    def enterLineaVacia(self, ctx:ExprParser.LineaVaciaContext):
        pass

    # Exit a parse tree produced by ExprParser#lineaVacia.
    def exitLineaVacia(self, ctx:ExprParser.LineaVaciaContext):
        pass


    # Enter a parse tree produced by ExprParser#parentesis.
    def enterParentesis(self, ctx:ExprParser.ParentesisContext):
        pass

    # Exit a parse tree produced by ExprParser#parentesis.
    def exitParentesis(self, ctx:ExprParser.ParentesisContext):
        pass


    # Enter a parse tree produced by ExprParser#sumaResta.
    def enterSumaResta(self, ctx:ExprParser.SumaRestaContext):
        pass

    # Exit a parse tree produced by ExprParser#sumaResta.
    def exitSumaResta(self, ctx:ExprParser.SumaRestaContext):
        pass


    # Enter a parse tree produced by ExprParser#multDiv.
    def enterMultDiv(self, ctx:ExprParser.MultDivContext):
        pass

    # Exit a parse tree produced by ExprParser#multDiv.
    def exitMultDiv(self, ctx:ExprParser.MultDivContext):
        pass


    # Enter a parse tree produced by ExprParser#complejo.
    def enterComplejo(self, ctx:ExprParser.ComplejoContext):
        pass

    # Exit a parse tree produced by ExprParser#complejo.
    def exitComplejo(self, ctx:ExprParser.ComplejoContext):
        pass


    # Enter a parse tree produced by ExprParser#variable.
    def enterVariable(self, ctx:ExprParser.VariableContext):
        pass

    # Exit a parse tree produced by ExprParser#variable.
    def exitVariable(self, ctx:ExprParser.VariableContext):
        pass


    # Enter a parse tree produced by ExprParser#entero.
    def enterEntero(self, ctx:ExprParser.EnteroContext):
        pass

    # Exit a parse tree produced by ExprParser#entero.
    def exitEntero(self, ctx:ExprParser.EnteroContext):
        pass


    # Enter a parse tree produced by ExprParser#flotante.
    def enterFlotante(self, ctx:ExprParser.FlotanteContext):
        pass

    # Exit a parse tree produced by ExprParser#flotante.
    def exitFlotante(self, ctx:ExprParser.FlotanteContext):
        pass



del ExprParser